let min = 00
let sec = 00
let ms = 00

const socket = io()
let minpanel = document.getElementById('min')
let secpanel = document.getElementById('sec')
let mspanel = document.getElementById('ms')
let display = document.querySelector('.time')
let Interval
let counter = true



document.addEventListener('keyup', (event)=>{
    clearInterval(Interval)
    if(counter == true){
        ms = 0
        sec = 0
        min = 0
        clearDisplay()
        Interval = setInterval(startTime,10)
        display.style.color='black'
        counter = false  
    }else{
        counter = true
    }
    
})


document.addEventListener('keydown', (event)=>{
    if(counter == true){
        display.style.color='green'
    }else{
        clearInterval(Interval)  
        
    }

})

clearDisplay = ()=>{
    mspanel.innerHTML = '00'
    secpanel.innerHTML = '00'
    minpanel.innerHTML = '00'
}

startTime = ()=>{
    ms++
    if(ms<=99){
        mspanel.innerHTML = ms
        
    }else if(ms = 100){
        ms = 0
        sec++
        mspanel.innerHTML = ms
        secpanel.innerHTML = sec
    }   
}

/**
    if(event.code === 'Space'){
        console.log('')
        socket.emit('getTime',{lastSolve:1.003})
    } */