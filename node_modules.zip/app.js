let express = require('express')
let app = express()
let bodyParser = require('body-parser')
let mongodb = require("mongodb")
let mongoose = require("mongoose")
let urlencodedParser = bodyParser.urlencoded({ extended: false })
const http = require('http')
const { Socket } = require('socket.io')

const server = http.Server(app).listen(8080)
const io = require('socket.io')(server)




app.use(express.static('public'))

app.set('view engine', 'ejs');

app.get('/', (req, res)=>{
    res.render('timer')
})

io.on('connection', (socket)=>{
    socket.on('getTime',(data)=>{
        console.log(data.lastSolve)
    })
})

